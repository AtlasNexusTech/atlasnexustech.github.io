# Template Artisan — Site vitrine PWA pour artisans

> Un template professionnel, responsive, PWA, SEO-ready. Modifiez un simple `config.json`, déployez sur GitHub Pages. **Zéro code.**

## 📦 Contenu du package

```
template-artisan/
├── index.html          ← Le site (PWA, responsive, Tailwind)
├── config.json         ← VOS infos (nom, services, couleurs…)
├── manifest.json       ← PWA manifest
├── sw.js               ← Service worker (mode hors-ligne)
├── images/             ← 6 photos pros + icônes
│   ├── hero.jpg
│   ├── work1-6.jpg
│   ├── icon-192.png
│   └── icon-512.png
├── genere-demo.py      ← Script de génération (6 secteurs)
└── README.md           ← Ce guide
```

## 🚀 Déploiement en 5 minutes

### 1. Modifiez `config.json`

Ouvrez le fichier et remplacez les infos d'exemple par les vôtres :

```json
{
  "business": {
    "name": "Dupont Maçonnerie",
    "shortName": "Dupont",
    "slogan": "Artisan de confiance depuis 1998",
    "since": "Depuis 1998",
    "description": "Maçonnerie traditionnelle. Devis gratuit, travail soigné.",
    "phone": "06 12 34 56 78",
    "email": "contact@dupont-maconnerie.fr",
    "address": "15 rue des Artisans, 75000 Paris",
    "zone": "Paris et Île-de-France",
    "siret": "123 456 789 00000"
  },
  "design": {
    "primary": "#b74709",           ← Couleur principale
    "primaryDark": "#76310f",       ← Couleur foncée
    "accent": "#ec7a12",            ← Couleur d'accent
    "fontHeading": "Playfair Display",
    "fontBody": "Inter",
    "heroImage": "images/hero.jpg",
    "logoEmoji": "🧱"               ← Emoji du métier
  },
  "services": [
    {"icon": "🏗️", "title": "Gros œuvre", "desc": "Construction neuve, rénovation."},
    {"icon": "🧱", "title": "Maçonnerie", "desc": "Murs, clôtures, dallage."},
    {"icon": "🏠", "title": "Aménagement", "desc": "Terrasses, allées, pavage."},
    {"icon": "🎨", "title": "Finitions", "desc": "Enduits, peinture, carrelage."}
  ],
  "gallery": [
    {"src": "images/work1.jpg", "alt": "Réalisation 1"},
    ...
  ],
  "features": [
    {"icon": "🎯", "title": "Travail soigné", "desc": "Finitions impeccables."},
    {"icon": "💰", "title": "Juste prix", "desc": "Devis gratuit, transparent."},
    {"icon": "🤝", "title": "Proximité", "desc": "Intervention rapide."}
  ],
  "seo": {
    "title": "Dupont Maçonnerie — Artisan à Paris",
    "description": "Artisan maçon à Paris. Devis gratuit.",
    "keywords": "maçon, maçonnerie, artisan, Paris"
  }
}
```

### 2. Déployez sur GitHub Pages (gratuit)

1. Créez un compte gratuit sur [github.com](https://github.com)
2. Créez un nouveau dépôt : `mon-artisan` (ou votre nom)
3. Glissez-déposez tous les fichiers du template dans le dépôt
4. Allez dans Settings → Pages → Source: `main` → Save
5. Votre site est en ligne sur `votrenom.github.io/mon-artisan` !

**Tutoriel vidéo pas à pas inclus dans le guide complet.**

### 3. (Optionnel) Connectez votre nom de domaine

1. Achetez un nom de domaine (OVH, Gandi, Ionos — ~10€/an)
2. Dans Settings → Pages → Custom domain, entrez `mon-artisan.fr`
3. Ajoutez les enregistrements DNS indiqués
4. Votre site est sur votre propre domaine !

### 4. Remplacez les images

Les images fournies sont des **exemples libres de droits** (Unsplash). Remplacez-les par vos vraies photos de chantier pour un rendu authentique.

## 🎨 6 secteurs pré-paramétrés

Le script `genere-demo.py` génère un site complet pour 6 secteurs :

| Secteur | Couleur | Slug |
|---------|---------|------|
| 🧱 Maçonnerie | #b74709 | maconnerie |
| 🎨 Peinture | #dd5f08 | peinture |
| 🪵 Menuiserie | #8b7358 | menuiserie |
| 🔩 Métallerie | #4a3b33 | metallerie |
| 🍽️ Restaurant | #c2410c | restaurant |
| 🏠 Générique | #2563EB | generique |

```bash
# Générez votre site en une commande
python3 genere-demo.py "Dupont Maçonnerie" \
  --secteur maconnerie \
  --ville "Paris (75)" \
  --tel "06 12 34 56 78" \
  --email "contact@dupont.fr"
```

## ✨ Fonctionnalités

- 📱 **PWA installable** — Le site s'installe sur le téléphone comme une app
- 🔍 **SEO optimisé** — Balises meta, schema.org, titre, description
- 📱 **Responsive** — S'adapte à tous les écrans (mobile, tablette, desktop)
- 🎨 **Personnalisable** — Couleurs, polices, icônes, contenu
- ⚡ **Rapide** — HTML pur + Tailwind CDN, aucun build
- 🆓 **Hébergement gratuit** — GitHub Pages, illimité
- 🔒 **HTTPS inclus** — Certificat SSL automatique

## ❓ FAQ

**Je n'y connais rien en code, je vais y arriver ?**
Oui. Le `config.json` est un formulaire texte simple. Vous copiez-collez vos infos. Le guide explique tout.

**C'est gratuit après l'achat ?**
Oui. L'hébergement GitHub Pages est gratuit à vie. Pas d'abonnement.

**Je peux modifier le design ?**
Oui, le template utilise Tailwind CSS. Si vous connaissez le CSS, tout est personnalisable. Sinon, le config.json couvre 90% des besoins.

**Mises à jour ?**
Incluses à vie. Vous serez notifié des améliorations.

## 📄 Licence

Ce template est fourni avec une **licence mono-site**. Vous pouvez l'utiliser pour UN site (le vôtre ou celui d'un client). Pour une utilisation multi-site (agence, freelance), contactez-nous.

---

**Template créé par Atlas Nexus** — [atlasnexus.tech](https://atlasnexus.tech)
