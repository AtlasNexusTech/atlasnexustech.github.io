#!/usr/bin/env python3
"""
genere-demo.py — Semi-automatisation des demos artisans
Usage: python3 genere-demo.py "Nom Prospect" --secteur maconnerie --ville "Estissac (10)" --tel "06..." --email "x@y.fr"

Genere:
  1. Dossier de demo pret a deployer sur atlasnexus.tech/{slug}/
  2. config.json pour le PWA template
  3. Card HTML pour /demos-web/
  4. Article Dev.to pret a publier
"""

import json, os, sys, argparse, shutil, re
from pathlib import Path

PORTFOLIO_DIR = Path.home() / "atlasnexusops.github.io"
PWA_TEMPLATE = PORTFOLIO_DIR / "pwa-template"
DEVTO_API_KEY = "tQxUP22D9YGedhrvz5hPUn6R"

SECTORS = {
    "maconnerie":    {"emoji": "\U0001f9f1", "primary": "#b74709", "primaryDark": "#76310f", "accent": "#ec7a12",
                      "services": [
                          {"icon": "\U0001f3d7", "title": "Maconnerie traditionnelle", "desc": "Construction neuve, renovation, extension."},
                          {"icon": "\U0001f9f1", "title": "Murs & clotures", "desc": "Murs porteurs, clotures, murets decoratifs."},
                          {"icon": "\U0001f3e0", "title": "Dallage & terrasses", "desc": "Dalles, pavage, terrasses, allees."},
                          {"icon": "\U0001faa8", "title": "Taille de pierre", "desc": "Restauration, pierre de taille, encadrements."},
                      ],
                      "zone_pattern": "{ville} et alentours"},
    "peinture":      {"emoji": "\U0001f3a8", "primary": "#dd5f08", "primaryDark": "#92380e", "accent": "#f09232",
                      "services": [
                          {"icon": "\U0001f3a8", "title": "Peinture interieure", "desc": "Murs, plafonds, boiseries, finitions soignees."},
                          {"icon": "\U0001f3e0", "title": "Ravalement facade", "desc": "Nettoyage, traitement, peinture exterieure."},
                          {"icon": "\U0001fab5", "title": "Traitement bois", "desc": "Boiseries, charpentes, traitement curatif."},
                          {"icon": "\U0001f9f9", "title": "Nettoyage toiture", "desc": "Demoussage, hydrofuge, protection durable."},
                      ],
                      "zone_pattern": "{ville}"},
    "menuiserie":    {"emoji": "\U0001fab5", "primary": "#8b7358", "primaryDark": "#5f4c3e", "accent": "#a0886e",
                      "services": [
                          {"icon": "\U0001fa9a", "title": "Menuiserie sur mesure", "desc": "Fabrication, pose, agencement bois."},
                          {"icon": "\U0001fa9f", "title": "Fenetres & portes", "desc": "Pose PVC, bois, alu. Isolation thermique."},
                          {"icon": "\U0001fa91", "title": "Agencement interieur", "desc": "Placards, dressing, bibliotheques."},
                          {"icon": "\U0001f3d7", "title": "Charpente & ossature", "desc": "Construction bois, extension, surelevation."},
                      ],
                      "zone_pattern": "{ville}, {departement}"},
    "metallerie":    {"emoji": "\U0001f529", "primary": "#4a3b33", "primaryDark": "#1f1815", "accent": "#ec7a12",
                      "services": [
                          {"icon": "\U0001f527", "title": "Metallerie", "desc": "Portails, garde-corps, verrieres, escaliers."},
                          {"icon": "\U0001f525", "title": "Soudure", "desc": "Acier, inox, aluminium, fonte."},
                          {"icon": "\U0001fa91", "title": "Mobilier design", "desc": "Tables, chaises, lampes sur mesure."},
                          {"icon": "\u2699", "title": "Usinage & reparation", "desc": "Tournage, fraisage, pieces uniques."},
                      ],
                      "zone_pattern": "{ville}, {departement}"},
    "generique":     {"emoji": "\U0001f3e0", "primary": "#2563EB", "primaryDark": "#1D4ED8", "accent": "#3B82F6",
                      "services": [
                          {"icon": "\U0001f3d7", "title": "Service principal", "desc": "Description du service phare."},
                          {"icon": "\U0001f527", "title": "Service secondaire", "desc": "Autre prestation importante."},
                          {"icon": "\U0001f4cb", "title": "Devis gratuit", "desc": "Etude personnalisee sans engagement."},
                          {"icon": "\U0001f69a", "title": "Intervention rapide", "desc": "Disponible sous 48h."},
                      ],
                      "zone_pattern": "{ville}"},
}

SELLING_POINTS = {
    "maconnerie": [
        {"icon": "\U0001f3af", "title": "Travail soigne", "desc": "Finitions impeccables, regles de l'art."},
        {"icon": "\U0001f4d0", "title": "Sur mesure", "desc": "Chaque projet est unique, adapte a vos besoins."},
        {"icon": "\U0001f91d", "title": "Devis gratuit", "desc": "Transparent, detaille, sans engagement."},
    ],
    "peinture": [
        {"icon": "\U0001f3af", "title": "Produits pros", "desc": "Peintures et traitements certifies professionnels."},
        {"icon": "\U0001f6e1", "title": "Protection", "desc": "Vos plantes et mobilier proteges pendant le chantier."},
        {"icon": "\U0001f91d", "title": "Conseil couleur", "desc": "Accompagnement dans le choix des teintes et finitions."},
    ],
    "menuiserie": [
        {"icon": "\U0001fab5", "title": "Bois selectionne", "desc": "Essences de qualite, origine tracee."},
        {"icon": "\U0001f4d0", "title": "Precision", "desc": "Mesures au laser, pose millimetree."},
        {"icon": "\u267b", "title": "Eco-responsable", "desc": "Chutes recyclees, produits eco-labellises."},
    ],
    "metallerie": [
        {"icon": "\u26a1", "title": "Sur mesure", "desc": "Chaque piece est unique, pensee pour votre espace."},
        {"icon": "\U0001f6e1", "title": "Qualite pro", "desc": "Materiaux certifies, finitions soignees."},
        {"icon": "\U0001f91d", "title": "Etude a domicile", "desc": "Deplacement gratuit pour devis personnalise."},
    ],
    "generique": [
        {"icon": "\U0001f3af", "title": "Professionnalisme", "desc": "Travail soigne, delais respectes."},
        {"icon": "\U0001f4b0", "title": "Juste prix", "desc": "Devis gratuit, transparent, detaille."},
        {"icon": "\U0001f91d", "title": "Proximite", "desc": "A votre ecoute, intervention rapide."},
    ],
}

def slugify(text):
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text[:40]

def generate_config(name, secteur, ville, departement, tel, email, address, since, zone_override=None):
    s = SECTORS.get(secteur, SECTORS["generique"])
    zone = zone_override or s["zone_pattern"].format(ville=ville, departement=departement or "")
    slug = slugify(name)
    
    return {
        "business": {
            "name": name,
            "shortName": name.split()[-1] if " " in name else name,
            "slogan": f"Artisan {secteur} a {ville}",
            "since": since or "Depuis 2010",
            "description": f"{name} \u2014 artisan {secteur} a {ville}. {s['services'][0]['desc']} Devis gratuit.",
            "phone": tel,
            "email": email,
            "address": address or f"{ville}",
            "zone": zone,
            "siret": ""
        },
        "design": {
            "primary": s["primary"],
            "primaryDark": s["primaryDark"],
            "accent": s["accent"],
            "fontHeading": "Playfair Display",
            "fontBody": "Inter",
            "heroImage": "images/hero.jpg",
            "logoEmoji": s["emoji"]
        },
        "services": s["services"],
        "gallery": [
            {"src": "https://placehold.co/600x450/eeeeee/999999?text=Realisation+1", "alt": "Realisation 1"},
            {"src": "https://placehold.co/600x450/eeeeee/999999?text=Realisation+2", "alt": "Realisation 2"},
            {"src": "https://placehold.co/600x450/eeeeee/999999?text=Realisation+3", "alt": "Realisation 3"},
            {"src": "https://placehold.co/600x450/eeeeee/999999?text=Realisation+4", "alt": "Realisation 4"},
        ],
        "features": SELLING_POINTS.get(secteur, SELLING_POINTS["generique"]),
        "seo": {
            "title": f"{name} \u2014 Artisan {secteur} a {ville}",
            "description": f"Artisan {secteur} qualifie a {ville}. Devis gratuit, intervention rapide. {s['services'][0]['desc']}",
            "keywords": f"artisan {secteur}, {secteur} {ville}, devis gratuit {secteur}"
        }
    }, slug, s

def generate_card_html(slug, name, emoji, ville, departement, description):
    safe_name = name.replace(" ", "+")
    short_desc = description[:50] if description else ""
    return f"""        <a href="/{slug}/" class="reveal reveal-delay-3 card-hover market-card rounded-2xl overflow-hidden border border-border bg-white dark:bg-dark-card flex flex-col">
          <div class="h-40 bg-stone-200 overflow-hidden"><img src="https://placehold.co/600x400/eeeeee/999999?text={safe_name}" alt="{name}" class="w-full h-full object-cover"></div>
          <div class="p-4"><span class="font-bold text-foreground dark:text-dark-foreground">{emoji} {name}</span><p class="text-slate-500 text-xs mt-1">{ville}, {departement or ''} - {short_desc}</p></div>
        </a>"""

def generate_devto_article(name, secteur, ville, slug, services):
    service_list = "\n".join([f"- **{s['title']}** : {s['desc']}" for s in services])
    
    return {
        "article": {
            "title": f"Refonte web pour {name} - Artisan {secteur} a {ville}",
            "description": f"Demonstration d'un site vitrine moderne pour {name}, artisan {secteur} a {ville}. Design responsive, formulaire de devis, SEO local.",
            "body_markdown": f"""## Le projet

J'ai realise une demonstration de site vitrine pour **{name}**, artisan {secteur} base a {ville}.

[Voir la demo live](https://atlasnexus.tech/{slug}/)

## Prestations presentes sur le site

{service_list}

## Ce qui change

- **Design responsive** : le site s'adapte aux mobiles
- **Formulaire de devis** integre 24h/24
- **SEO local** optimise "{secteur} {ville}"
- **Galerie photos** des realisations
- **Performance** : chargement rapide, PWA installable

## Stack technique

- HTML/CSS Tailwind (CDN, zero dependance)
- PWA (Service Worker, installable sur mobile)
- Hebergement GitHub Pages (gratuit)
- Formulaire de contact pret a brancher

## Offre

Forfait **300 EUR** pour une refonte complete :
- Site responsive 5 pages
- Formulaire de devis
- Optimisation SEO local
- Mise en ligne + nom de domaine

## Liens

- [Demo live](https://atlasnexus.tech/{slug}/)
- [Portfolio AtlasNexus](https://atlasnexus.tech/demos-web/)

---

*Article publie dans le cadre du projet AtlasNexus.*
""",
            "tags": ["webdev", "artisan", "refonte", "tailwindcss", "pwa"],
            "series": "Refontes artisans",
            "published": False,
            "canonical_url": f"https://atlasnexus.tech/{slug}/"
        }
    }

def main():
    parser = argparse.ArgumentParser(description="Genere une demo artisan complete")
    parser.add_argument("name", help="Nom du prospect (ex: 'E.D. Maconnerie')")
    parser.add_argument("--secteur", default="generique", choices=list(SECTORS.keys()), help="Secteur d'activite")
    parser.add_argument("--ville", default="", help="Ville")
    parser.add_argument("--departement", default="", help="Departement (ex: '63')")
    parser.add_argument("--tel", default="06 00 00 00 00", help="Telephone")
    parser.add_argument("--email", default="contact@exemple.fr", help="Email")
    parser.add_argument("--adresse", default="", help="Adresse complete")
    parser.add_argument("--since", default="", help="Annee de creation (ex: 'Depuis 2001')")
    parser.add_argument("--zone", default=None, help="Zone d'intervention (override)")
    parser.add_argument("--auto", action="store_true", help="Pipeline complet: commit, push, card, Dev.to")
    args = parser.parse_args()

    print(f"\nGeneration de la demo pour : {args.name}")
    print(f"   Secteur: {args.secteur} | Ville: {args.ville}")
    
    config, slug, s = generate_config(
        args.name, args.secteur, args.ville, args.departement,
        args.tel, args.email, args.adresse, args.since, args.zone
    )
    
    # 1. Creer le dossier de la demo
    demo_dir = PORTFOLIO_DIR / slug
    demo_dir.mkdir(exist_ok=True)
    
    # Copier le template PWA
    for f in PWA_TEMPLATE.glob("*"):
        if f.is_file() and f.name != "config.json":
            shutil.copy2(f, demo_dir / f.name)
    
    # Ecrire le config.json personnalise
    with open(demo_dir / "config.json", "w") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    print(f"\n[OK] Dossier demo: {demo_dir}")
    print(f"[OK] config.json genere")
    print(f"URL: https://atlasnexus.tech/{slug}/")
    
    # 2. Generer la card HTML pour demos-web
    card = generate_card_html(slug, args.name, s["emoji"], args.ville, args.departement, config["business"]["description"])
    print(f"\n--- CARD HTML (a inserer dans demos-web/index.html) ---")
    print(card)
    
    # 3. Generer l'article Dev.to
    devto = generate_devto_article(args.name, args.secteur, args.ville, slug, s["services"])
    article_path = demo_dir / "article-devto.md"
    with open(article_path, "w") as f:
        f.write(devto["article"]["body_markdown"])
    print(f"\n[OK] Article Dev.to: {article_path}")
    print(f"Titre: {devto['article']['title']}")
    
    # 4. Instructions + actions automatiques
    auto = getattr(args, 'auto', False)
    
    if auto:
        import subprocess
        # a. Ajouter la card dans demos-web
        demos_path = PORTFOLIO_DIR / "demos-web" / "index.html"
        with open(demos_path) as f:
            demos_html = f.read()
        
        # Inserer avant le dernier </div> du grid
        marker = '        </a>\n      </div>\n    </div>\n  </section>'
        insertion = card + "\n"
        if insertion not in demos_html:
            demos_html = demos_html.replace(marker, insertion + marker)
            with open(demos_path, "w") as f:
                f.write(demos_html)
            print(f"\n[OK] Card inseree dans demos-web/")
        
        # b. Commit + push
        subprocess.run(["git", "add", slug + "/", "demos-web/"], cwd=PORTFOLIO_DIR)
        subprocess.run(["git", "commit", "-m", f"Ajout demo {args.name} ({args.secteur})"], cwd=PORTFOLIO_DIR)
        subprocess.run(["git", "push", "origin", "main"], cwd=PORTFOLIO_DIR)
        print(f"[OK] Demo push sur GitHub")
        
        # c. Publier sur Dev.to
        devto_path = demo_dir / "article-devto.md"
        import urllib.request as ur
        with open(devto_path) as f:
            body = f.read()
        article_data = {
            "article": {
                "title": devto["article"]["title"],
                "description": devto["article"]["description"],
                "body_markdown": body,
                "tags": ["webdev", "artisan", "refonte", "tailwindcss", "pwa"],
                "published": False,
                "canonical_url": f"https://atlasnexus.tech/{slug}/"
            }
        }
        req = ur.Request(
            "https://dev.to/api/articles",
            data=json.dumps(article_data).encode(),
            headers={"Content-Type": "application/json", "api-key": DEVTO_API_KEY, "User-Agent": "AtlasNexusOps"},
            method="POST"
        )
        try:
            resp = ur.urlopen(req)
            devto_resp = json.loads(resp.read())
            print(f"[OK] Article Dev.to: https://dev.to/{devto_resp.get('slug', '?')}")
        except Exception as e:
            print(f"[WARN] Dev.to publish failed: {e}")
        
        print(f"\n[TERMINE] Demo en ligne: https://atlasnexus.tech/{slug}/")
    else:
        print(f"\n=== PROCHAINES ETAPES ===")
        print(f"1. cd {PORTFOLIO_DIR}")
        print(f"2. git add {slug}/")
        print(f"3. Inserer la card HTML dans demos-web/index.html")
        print(f"4. git add demos-web/ && git commit -m 'Ajout demo {args.name}'")
        print(f"5. git push origin main")
        print(f"6. python3 ~/publie-devto.py {demo_dir}/article-devto.md")

if __name__ == "__main__":
    main()
